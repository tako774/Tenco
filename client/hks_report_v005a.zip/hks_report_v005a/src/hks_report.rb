require 'sqlite3'
require 'kconv'
require 'net/http'
Net::HTTP.version_1_2 
require 'rexml/document'
require 'yaml'
require 'time'
require 'digest/sha1'

# プログラム情報
PROGRAM_VERSION = '0.05a'
TRACKRECORD_POST_SIZE = 250   # 一度に送信する対戦結果数
MAIL_ADDRESS_REGEX = /\A[\x01-\x7F]+@(([-a-z0-9]+\.)*[a-z]+|\[\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\])\z/ # メールアドレスチェック用正規表現
DEFAULT_GAME_ID = 1  # 設定で読み込めなかったときのゲームID
ERROR_LOG_PATH = 'error.txt'

print "*** 緋行跡報告ツール *** ver.#{PROGRAM_VERSION}\n\n".kconv(Kconv::SJIS, Kconv::UTF8)

begin

### 設定読み込み ###

# 設定ファイルパス
config_file = 'config.yaml'
config_default_file = 'config_default.yaml'
env_file = 'env.yaml'

# 設定ファイルがなければデフォルトをコピーして作成
unless File.exist?(config_file) then
	open(config_default_file) do |s|
		open(config_file, "w") do |d|
			d.write(s.read)
		end
	end
end

# サーバー環境設定ファイルがなければ、エラー終了
unless File.exist?(env_file) then
	raise "#{env_file} が見つかりません。\nダウンロードした本プログラムのフォルダからコピーしてください。"
end

# 設定ファイル読み込み
config = YAML.load_file(config_file)
env = YAML.load_file(env_file)

# config.yaml がおかしいと代入時にエラーが出ることに対する格好悪い対策
config ||= {}
config['account'] ||= {}
config['game'] ||= {}
config['database'] ||= {}

account_name = config['account']['name'] || ''
account_password = config['account']['password'] || ''
game_id = config['game']['id'] || DEFAULT_GAME_ID
db_file = config['database']['file_path'] || ''
# proxy_host = config['proxy']['host']
# proxy_port = config['proxy']['port']
# last_report_time = config['last_report_time']
# IS_USE_HTTPS = false

SERVER_TRACK_RECORD_HOST = env['server']['track_record']['host']
SERVER_TRACK_RECORD_PATH = env['server']['track_record']['path']
SERVER_LAST_TRACK_RECORD_HOST = env['server']['last_track_record']['host']
SERVER_LAST_TRACK_RECORD_PATH = env['server']['last_track_record']['path']
SERVER_ACCOUNT_HOST = env['server']['account']['host']
SERVER_ACCOUNT_PATH = env['server']['account']['path']

### メソッド定義 ###

# 試合結果データ読み込み
# 発生時間が古い順にデータを並べて返す
# 指定されたデータベースファイルが存在しなければ、例外を発生させる
def read_trackrecord(db_file, last_report_filetime)
	trackrecord = Array.new()
	last_report_filetime = 0 unless last_report_filetime
	
	# 緋行跡DB接続
	# DBファイルがなければ例外発生
	raise <<-MSG unless File.exist?(db_file.kconv(Kconv::SJIS, Kconv::UTF8))
緋行跡データベースファイルが見つかりません。(パス：#{db_file})
・緋行跡報告ツールのインストール場所が正しいかどうか
・緋行跡Rev.10**系列を使っているかどうか（Rev.1*系列は未対応です）
・Default以外の緋行跡のプロファイル（緋想天のデッキ名ではありません）を使っているかどうか
・Default以外のプロファイルを使用している場合、config.yaml の設定が正しいかどうか
以上の点をご確認ください。
MSG
	
	db = SQLite3::Database.open(db_file)
	db.results_as_hash = true

	# 試合結果記録の読み込み
	sql = <<SQL
SELECT *
FROM
	trackrecord
WHERE
	    timestamp > #{last_report_filetime.to_i}
	AND	coalesce(p1name, '') != ''
	AND p1id >= 0
	AND p1win >= 0
	AND coalesce(p2name, '') != ''
	AND p2id >= 0
	AND p2win >= 0
ORDER BY
	timestamp
SQL

	db.execute(sql) do |row|
		trackrecord << row
	end		
	
	db.close

	return trackrecord
end

# 緋行跡データをポスト用XMLに変換
def trackrecord2xml_string(game_id, account_name, account_password, trackrecord)
	# XML生成
	xml = REXML::Document.new
	xml << REXML::XMLDecl.new('1.0', 'UTF-8')
	
	# trackrecordPosting 要素生成
	root = xml.add_element('trackrecordPosting')
	
	# account 要素生成
	account_element = root.add_element('account')
	account_element.add_element('name').add_text(account_name.to_s)
	account_element.add_element('password').add_text(Digest::SHA1.hexdigest(account_password.to_s))
	
	# game 要素生成
	game_element = root.add_element('game')
	game_element.add_element('id').add_text(game_id.to_s)
	
	# trackrecord 要素生成
	trackrecord.each do |t|
		trackrecord_element = game_element.add_element('trackrecord')
		trackrecord_element.add_element('timestamp').add_text(t['timestamp'].to_s)
		trackrecord_element.add_element('p1name').add_text(t['p1name'].to_s)
		trackrecord_element.add_element('p1type').add_text(t['p1id'].to_s)
		trackrecord_element.add_element('p1point').add_text(t['p1win'].to_s)
		trackrecord_element.add_element('p2name').add_text(t['p2name'].to_s)
		trackrecord_element.add_element('p2type').add_text(t['p2id'].to_s)
		trackrecord_element.add_element('p2point').add_text(t['p2win'].to_s)
	end
	
	return xml.to_s
end

# 緋行跡のタイムスタンプ (FILETIME)を ISO8601 形式に変換
# FILETIME は 1601年1月1日からの100ナノ秒単位での時間
# 緋行跡はローカル時刻を取得しているので、ローカルの時刻オフセットをつける
def filetime_to_iso8601 (filetime)
	# DateTime モジュールだと計算精度が低かったので Time モジュールを利用
	if filetime then
		base_filetime = 126227808000000000   # 2001年1月1日0時の FILETIME
		base_time = Time.local(2001, 1, 1)
		time = base_time + (filetime.to_i - base_filetime) / 10.0**7
		return time.iso8601
	else
		return nil
	end
end

# Time型のインスタンス を FILETIME に変換
# FILETIME は 1601年1月1日からの100ナノ秒単位でのローカル時間
def time_to_filetime (time)
	if time then
	    base_filetime = 126227808000000000   # 2001年1月1日0時の FILETIME
		base_time = Time.local(2001, 1, 1)
		return base_filetime + (time - base_time) * 10**7
	else
		return nil
	end
end

# UTF8文字列をデコード
# YAML(Syck) の to_yaml が日本語対応してない対策
def decode (string)
	string.gsub(/\\x(\w{2})/){[Regexp.last_match.captures.first.to_i(16)].pack("C")}
end

### メイン処理 ###
unless (account_name && account_name =~ /\A[a-zA-Z0-9_\.]+\z/) then
	# 新規アカウント登録処理
	account_name = ''
	account_password = ''
	is_account_register_finish = false
	
	puts "★新規アカウント登録\n\n".kconv(Kconv::SJIS, Kconv::UTF8)
	puts "※もしすでにアカウントを持ってるのであれば、今すぐ Ctrl+C を押して中止し、設定ファイル（#{config_file}）にアカウント名とパスワードを書き込んで、再度実行してください。\n\n".kconv(Kconv::SJIS, Kconv::UTF8)

	while (!is_account_register_finish)
		# アカウント名入力
		puts "希望アカウント名を入力してください\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "アカウント名はURLの一部として使用されます。\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "（半角英数とアンダースコア_のみ使用可能。32文字以内）\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "希望アカウント名：".kconv(Kconv::SJIS, Kconv::UTF8)
		while (input = gets)
			input.strip!
			if input =~ /\A[a-zA-Z0-9_]{1,32}\z/ then
				account_name = input
				puts 
				break
			else
				puts "！希望アカウント名は半角英数とアンダースコア_のみで、32文字以内で入力してください".kconv(Kconv::SJIS, Kconv::UTF8)
				puts "希望アカウント名：".kconv(Kconv::SJIS, Kconv::UTF8)
			end
		end
		
		# パスワード入力
		puts "パスワードを入力してください（使用文字制限なし。4～16byte以内）\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "パスワード：".kconv(Kconv::SJIS, Kconv::UTF8)
		while (input = gets)
			input.strip!
			if (input.length >= 4 and input.length <= 16) then
				account_password = input
				break
			else
				puts "！パスワードは4～16byte以内で入力してください".kconv(Kconv::SJIS, Kconv::UTF8)
				puts "パスワード：".kconv(Kconv::SJIS, Kconv::UTF8)
			end
		end 
		
		puts "パスワード（確認）：\n".kconv(Kconv::SJIS, Kconv::UTF8)
		while (input = gets)
			input.strip!
			if (account_password == input) then
				puts 
				break
			else
				puts "！パスワードが一致しません\n".kconv(Kconv::SJIS, Kconv::UTF8)
				puts "パスワード（確認）：".kconv(Kconv::SJIS, Kconv::UTF8)
			end
		end
		
		# メールアドレス入力
		puts "メールアドレスを入力してください（入力は任意）\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "※パスワードを忘れたときの連絡用にのみ使用します。\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "※記入しない場合、パスワードの連絡はできません。\n".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "メールアドレス：".kconv(Kconv::SJIS, Kconv::UTF8)
		while (input = gets)
			input.strip!
			if (input == '') then
				account_mail_address = ''
				puts "メールアドレスは登録しません。".kconv(Kconv::SJIS, Kconv::UTF8)
				puts
				break
			elsif input =~ MAIL_ADDRESS_REGEX and input.length <= 256 then
				account_mail_address = input
				puts
				break
			else
				puts "！メールアドレスは正しい形式で、256byte以内にて入力してください".kconv(Kconv::SJIS, Kconv::UTF8)
				puts "メールアドレス：".kconv(Kconv::SJIS, Kconv::UTF8)
			end
		end
		
		# 新規アカウントをサーバーに登録
		puts "サーバーにアカウントを登録しています...\n".kconv(Kconv::SJIS, Kconv::UTF8)
		
		# アカウント XML 生成
		account_xml = REXML::Document.new
		account_xml << REXML::XMLDecl.new('1.0', 'UTF-8')
		account_element = account_xml.add_element("account")
		account_element.add_element('name').add_text(account_name)
		account_element.add_element('password').add_text(account_password)
		account_element.add_element('mail_address').add_text(account_mail_address)
		# サーバーに送信
		response = nil
		# http = Net::HTTP.new(SERVER_ACCOUNT_HOST, 443)
		# http.use_ssl = true
		# http.verify_mode = OpenSSL::SSL::VERIFY_NONE
		http = Net::HTTP.new(SERVER_ACCOUNT_HOST, 80)
		http.start do |s|
			response = s.post(SERVER_ACCOUNT_PATH, account_xml.to_s)
		end
		
		print "サーバーからのお返事\n".kconv(Kconv::SJIS, Kconv::UTF8)
		response.body.each_line do |line|
			puts "> #{line.kconv(Kconv::SJIS, Kconv::UTF8)}"
		end

		if response.code == '200' then
		# アカウント登録成功時
			is_account_register_finish = true
			config['account']['name'] = account_name
			config['account']['password'] = account_password
			
			File.open(config_file, 'w') do |w|
				w.puts "# 緋行跡報告ツール設定ファイル"
				w.puts "#"
				w.puts "# かならず文字コードは UTF-8N で保存してください。UTF-8 で保存すると、エラーが発生します。"
				w.puts "# 注意：メモ帳は、保存時に UTF-8 に勝手に変換してしまいます。"
				w.puts "# 　　　メモ帳以外の UTF-8N が扱えるエディタで保存してください。"
				w.puts decode(config.to_yaml)
			end
			
			puts 
			puts "アカウント情報を設定ファイルに保存しました。\n\n".kconv(Kconv::SJIS, Kconv::UTF8)
			puts "引き続き、対戦結果の報告をします...\n\n".kconv(Kconv::SJIS, Kconv::UTF8)
		else
		# アカウント登録失敗時
			puts "もう一度アカウント登録をやり直します...\n\n".kconv(Kconv::SJIS, Kconv::UTF8)
		end
		
		sleep 2
	end
end

## 登録済みの最終対戦結果時刻を取得する
puts "★登録済みの最終対戦時刻を取得".kconv(Kconv::SJIS, Kconv::UTF8)
puts "GET http://#{SERVER_LAST_TRACK_RECORD_HOST}#{SERVER_LAST_TRACK_RECORD_PATH}?game_id=#{game_id}&account_name=#{account_name}"

http = Net::HTTP.new(SERVER_LAST_TRACK_RECORD_HOST, 80)
response = nil
http.start do |s|
	response = s.get("#{SERVER_LAST_TRACK_RECORD_PATH}?game_id=#{game_id}&account_name=#{account_name}")
end

if response.code == '200' or response.code == '204' then
	if (response.body and response.body != '') then
		last_report_time = Time.parse(response.body)
		puts "サーバー登録済みの最終対戦時刻：#{last_report_time.strftime('%Y/%m/%d %H:%M:%S')}".kconv(Kconv::SJIS, Kconv::UTF8)
	else
		last_report_time = Time.at(0)
		puts "サーバーには対戦結果未登録です".kconv(Kconv::SJIS, Kconv::UTF8)
	end
else
	raise "最終対戦時刻の取得時にサーバーエラーが発生しました。処理を中断します。"
end
puts

## 対戦結果報告処理
puts "★対戦結果送信".kconv(Kconv::SJIS, Kconv::UTF8)
puts ("緋行跡の記録から、" + last_report_time.strftime('%Y/%m/%d %H:%M:%S') + " 以降の対戦結果を報告します。").kconv(Kconv::SJIS, Kconv::UTF8)

# 緋行跡DBから対戦結果を取得
trackrecord = read_trackrecord(db_file, time_to_filetime(last_report_time + 1))

# 報告対象データが0件なら送信しない
if trackrecord.length <= 0 then
	puts "報告対象データはありませんでした。".kconv(Kconv::SJIS, Kconv::UTF8)
else
	# 文字列をutf-8に変換
	trackrecord.each do |t|
		t['p1name'] = t['p1name'].kconv(Kconv::UTF8, Kconv::SJIS)
		t['p2name'] = t['p2name'].kconv(Kconv::UTF8, Kconv::SJIS)
	end
	# タイムスタンプをFILETIMEからISO8601形式に変換
	trackrecord.each do |t|
		t['timestamp'] = filetime_to_iso8601(t['timestamp'])
	end

	# 対戦結果データを分割して送信
	0.step(trackrecord.length ,TRACKRECORD_POST_SIZE) do |start_row_num|
		end_row_num = [start_row_num + TRACKRECORD_POST_SIZE - 1, trackrecord.length - 1].min
		response = nil # サーバーからのレスポンスデータ
		
		puts "#{trackrecord.length}件中の#{start_row_num + 1}件目～#{end_row_num + 1}件目を送信しています...\n".kconv(Kconv::SJIS, Kconv::UTF8)
		
		# 送信用XML生成
		trackrecord_xml_string = trackrecord2xml_string(game_id, account_name, account_password, trackrecord[start_row_num..end_row_num])
		File.open('./last_report_trackrecord.xml', 'w') do |w|
			w.puts trackrecord_xml_string
		end

		# データ送信
		# https = Net::HTTP.new(SERVER_TRACK_RECORD_HOST, 443)
		# https.use_ssl = true
		# https.verify_mode = OpenSSL::SSL::VERIFY_NONE
		# https = Net::HTTP::Proxy(proxy_addr, proxy_port).new(SERVER_TRACK_RECORD_HOST,443)
		# https.ca_file = '/usr/share/ssl/cert.pem'
		# https.verify_depth = 5
		# https.verify_mode = OpenSSL::SSL::VERIFY_PEER
		http = Net::HTTP.new(SERVER_TRACK_RECORD_HOST, 80)
		http.start do |s|
			response = s.post(SERVER_TRACK_RECORD_PATH, trackrecord_xml_string)
		end
		
		# 送信結果表示
		puts "サーバーからのお返事".kconv(Kconv::SJIS, Kconv::UTF8)
		response.body.each_line do |line|
			puts "> #{line.kconv(Kconv::SJIS, Kconv::UTF8)}"
		end
		puts
		
		if response.code == '200' then
			# 特に表示しない
		else
			raise "報告時にエラーが発生しました。処理を中断します。"
			break
		end
	end
end

# 設定ファイル更新
File.open(config_file, 'w') do |w|
	w.puts "# 緋行跡報告ツール設定ファイル"
	w.puts "#"
	w.puts "# かならず文字コードは UTF-8N で保存してください。UTF-8 で保存すると、エラーが発生します。"
	w.puts "# 注意：メモ帳は、保存時に UTF-8 に勝手に変換してしまいます。"
	w.puts "# 　　　メモ帳以外の UTF-8N が扱えるエディタで保存してください。"
	w.puts decode(config.to_yaml)
end

puts
puts "報告処理が正常に終了しました。".kconv(Kconv::SJIS, Kconv::UTF8)

sleep 3

### 全体エラー処理 ###
rescue => ex
	if config && config['account'] then
		config['account']['name']     = '<secret>' if config['account']['name']
		config['account']['password'] = '<secret>' if config['account']['password']
	end
	
	puts 
	puts "処理中にエラーが発生しました。処理を中断します。\n".kconv(Kconv::SJIS, Kconv::UTF8)
	puts 
	puts '### エラー詳細ここから ###'.kconv(Kconv::SJIS, Kconv::UTF8)
	puts
	puts ex.to_s.kconv(Kconv::SJIS, Kconv::UTF8)
	puts
	puts ex.backtrace.join("\n").kconv(Kconv::SJIS, Kconv::UTF8)
	puts (config ? decode(config.to_yaml) : "config が設定されていません。").kconv(Kconv::SJIS, Kconv::UTF8)
	if response then
		puts
		puts "<サーバーからの最後のメッセージ>".kconv(Kconv::SJIS, Kconv::UTF8)
		puts "HTTP status code : #{response.code}"
		puts response.body.kconv(Kconv::SJIS, Kconv::UTF8)
	end
	puts
	puts '### エラー詳細ここまで ###'.kconv(Kconv::SJIS, Kconv::UTF8)
	
	File.open(ERROR_LOG_PATH, 'a') do |log|
		log.puts "#{Time.now.strftime('%Y/%m/%d %H:%M:%S')} #{File::basename(__FILE__)} #{PROGRAM_VERSION}" 
		log.puts ex.to_s
		log.puts ex.backtrace.join("\n")
		log.puts config ? decode(config.to_yaml) : "config が設定されていません。"
		if response then
			log.puts "<サーバーからの最後のメッセージ>"
			log.puts "HTTP status code : #{response.code}"
			log.puts response.body
		end
		log.puts '********'
	end
	
	puts
	puts "上記のエラー内容を #{ERROR_LOG_PATH} に書き出しました。".kconv(Kconv::SJIS, Kconv::UTF8)
	puts
	
	puts "Enter キーを押すと、処理を終了します。".kconv(Kconv::SJIS, Kconv::UTF8)
	exit if gets
end








