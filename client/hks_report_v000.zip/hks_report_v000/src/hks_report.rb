require 'sqlite3'
require 'kconv'
require 'net/http'
Net::HTTP.version_1_2
require 'yaml'

# 更新情報
PROGRAM_VERSION = '0.00α'
print "緋行跡報告ツール ver.#{PROGRAM_VERSION}\n".kconv(Kconv::SJIS, Kconv::UTF8)

# 設定ファイル読み込み
config_file = 'config.yaml'
config = YAML.load_file(config_file)

ACCOUNT_ID = config['account']['id']
ACCOUNT_PASSWORD = config['account']['password']
GAME_ID = config['game']['id']
GAME_VERSION = config['game']['version']
DB_FILE = config['database']['file_path']
TRACKRECORD_POST_SERVER = config['server']['post']['host']
TRACKRECORD_POST_PATH = config['server']['post']['path']

### メソッド定義 ###

# 試合結果データ読み込み
def read_trackrecord(db_file)
	trackrecord = Array.new()
	
	# 緋行跡DB接続
	db = SQLite3::Database.open(db_file)
	db.results_as_hash = true

	# 試合結果記録の読み込み
	db.execute("select * from trackrecord") do |row|
		trackrecord << row
	end		
	
	db.close

	return trackrecord
end

# 緋行跡データをポスト用XMLに変換
def trackrecord2xml_string(trackrecord)
	xml_string = <<HEAD
<?xml version="1.0" encoding="UTF-8" ?>
<trackrecordPosting>
	<game>
		<id>#{GAME_ID}</id>
		<version>#{GAME_VERSION}</version>
	</game>
	<account>
		<id>#{ACCOUNT_ID}</id>
		<password>#{ACCOUNT_PASSWORD}</password>
	</account>
HEAD

	trackrecord[0..4].each do |t|
		xml_string << <<DATA
	<trackrecord>
		<timestamp>#{t['timestamp']}</timestamp>
		<p1name>#{t['p1name']}</p1name>
		<p1id>#{t['p1id']}</p1id>
		<p1win>#{t['p1win']}</p1win>
		<p2name>#{t['p2name']}</p2name>
		<p2id>#{t['p2id']}</p2id>
		<p2win>#{t['p2win']}</p2win>
	</trackrecord>
DATA
	end
	
	xml_string << <<FOOTER
</trackrecordPosting>
FOOTER
	
	xml_string = xml_string.kconv(Kconv::UTF8, Kconv::SJIS)
	
	return xml_string
end

### メイン処理 ###
trackrecord = read_trackrecord(DB_FILE)
trackrecord_xml_string = trackrecord2xml_string(trackrecord)

print "サーバーにデータを送ります\n".kconv(Kconv::SJIS, Kconv::UTF8)
print "------------\n"
print trackrecord_xml_string.kconv(Kconv::SJIS, Kconv::UTF8)

Net::HTTP.start(TRACKRECORD_POST_SERVER, 80) do |http|
	response = http.post(TRACKRECORD_POST_PATH, trackrecord_xml_string)
	print "\nサーバーからのお返事\n".kconv(Kconv::SJIS, Kconv::UTF8)
	print "------------\n"
	puts response.body
end
